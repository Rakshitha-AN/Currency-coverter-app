

public interface money {
    double EUR0=92.17;
    double SGD=62.06;
    double AST=55.94;
    double USD=82.08;
    double CAD=62.32;
    double UKP=106.41;
    double CSY=11.43;
    double JPY=0.59;
    double RSR=0.91;
    double SKW=0.065;

}

