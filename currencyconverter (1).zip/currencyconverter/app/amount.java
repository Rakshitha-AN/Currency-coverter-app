public interface amount {

}
