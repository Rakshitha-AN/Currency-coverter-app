package com.example.currencyconverter;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.icu.util.Currency;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

@RequiresApi(api = Build.VERSION_CODES.N)
public class MainActivity extends AppCompatActivity {
EditText money_ET;
Button convert_btn;
Spinner spinner;
TextView rupees;

String EURO,USD,CAD,AUD,SGD,UKP,CNY,JPY,SKW,RSR;

ArrayAdapter adapter;


String list,getMoney;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EURO=getIntent().getStringExtra("EURO");
        USD=getIntent().getStringExtra("USD");
        CAD=getIntent().getStringExtra("CAD");
        AUD=getIntent().getStringExtra("AUD");
        SGD=getIntent().getStringExtra("SGD");
        UKP=getIntent().getStringExtra("UKP");
        CNY=getIntent().getStringExtra("CNY");
        JPY=getIntent().getStringExtra("JPY");
        SKW=getIntent().getStringExtra("SKW");
        RSR=getIntent().getStringExtra("RSR");

        money_ET = findViewById(R.id.value_ET);
        convert_btn = findViewById(R.id.conver_Btn);
        rupees = findViewById(R.id.rupees);
        spinner = findViewById(R.id.spinner);

        adapter = ArrayAdapter.createFromResource(this,R.array.currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                list = parent.getItemAtPosition(position).toString();


                switch (list){
                    case "EUR - Euro":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et *(Double.parseDouble(EURO))));
                                    rupees.setText(""+store);
                                }
                            }

                        });
                        break;
                    }
                    case "USD - US Dollar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * (Double.parseDouble( USD))));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }
                    case "CAD - Canadian Dollar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * Double.parseDouble(CAD)));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }
                    case "AUD - Australian Dollar":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * Double.parseDouble(AUD)));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }
                    case "SGD - Singapore":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * Double.parseDouble(SGD)));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }
                    case "UKP - UK Pound":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * Double.parseDouble(UKP)));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }
                    case "CNY - Chinese Yuan":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * Double.parseDouble(CNY)));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }
                    case "JPY - Japanese Yen":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * Double.parseDouble(JPY)));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }
                    case "SKW - South korean won":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * Double.parseDouble(SKW)));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }
                    case "RSR - Russian Ruble":{
                        convert_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                getMoney=money_ET.getText().toString();
                                if (getMoney.isEmpty()){
                                    Toast.makeText(getApplicationContext(),"please enter some amount to convert",Toast.LENGTH_SHORT).show();
                                }else {
                                    double convertToDouble_et = Double.parseDouble(getMoney);
                                    double store = Double.parseDouble(new DecimalFormat("##.####").format(convertToDouble_et * Double.parseDouble(RSR)));
                                    rupees.setText(""+store);
                                }
                            }
                        });
                        break;
                    }


                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });





    }
}