package com.example.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class currency extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currency);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            String EURO="92.17";
            String SGD="62.06";
            String AUD="55.94";
            String USD="82.08";
            String CAD="62.32";
            String UKP="106.41";
            String CSY="11.43";
            String  JPY="0.59";
            String  RSR="0.91";
            String  SKW="0.065";
            Intent intent=new Intent(this,MainActivity.class);
            intent.putExtra("EURO",EURO);
            intent.putExtra("SGD",SGD);
            intent.putExtra("AUD",AUD);
            intent.putExtra("USD",USD);
            intent.putExtra("CAD",CAD);
            intent.putExtra("UKP",UKP);
            intent.putExtra("CSY",CSY);
            intent.putExtra("JPY",JPY);
            intent.putExtra("RSR",RSR);
            intent.putExtra("SKW",SKW);

            startActivity(intent);
        }
    }
}